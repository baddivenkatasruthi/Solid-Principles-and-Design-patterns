public class ClientX {
    public static void main(String[] args) {
        System.out.println("A");
        Person p1 = new Person("Abc");
        Person p2 = new Person("BCD");
        System.out.println("B");
    }
}
