public class Client {
    public static void main(String[] args) {
        //read url , password , max
       DbconnectionPool pool1 = DbconnectionPool.getInstance();
       //DbconnectionPool pool2 = DbconnectionPool.getInstance();
        //DbconnectionPool.sayHello();
        System.out.println(pool1.url);
       DbconnectionPool.resetInstance();

        System.out.println(pool1.url);
        DbconnectionPool pool2 = DbconnectionPool.getInstance();


        System.out.println("DEBUG");

    }
}
