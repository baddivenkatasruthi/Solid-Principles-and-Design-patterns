import java.util.ArrayList;
import java.util.List;
public class DbconnectionPool {
    String url;
    private String password;
    private int maxPollsize;
    private List<String>connections;
    private static volatile DbconnectionPool instance;
    private DbconnectionPool(String url, String password, int maxPollsize) {
        this.url = url;
        this.password = password;
        this.maxPollsize = maxPollsize;
        this.connections = new ArrayList<>(maxPollsize);
    }
    //T1 : 2:47
    //T2 & T3 & T4 : 2:48
    //100

    public static  DbconnectionPool getInstance(){
        if(instance == null) {
            //T1 T2
            synchronized (DbconnectionPool.class) {
                //T1 --> T2
                if(instance == null) {
                    //3 steps
                    //1 step and 2nd creating -> assing instance
                    instance = new DbconnectionPool("url", "123", 5);
                }
            }

        }
        return instance;
    }
    public static void resetInstance(){
        instance = null;
    }
}
