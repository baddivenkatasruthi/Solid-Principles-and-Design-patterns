public class Person {

    private String name;
    static{
        System.out.println("CLass is loading");
    }
    public Person(String name) {
        this.name = name;
        System.out.println("Constructor is loading");
    }


}
